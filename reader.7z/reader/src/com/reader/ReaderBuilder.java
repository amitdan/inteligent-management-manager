
package com.reader;

import java.io.File;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * Builds reader
 * 
 * 
 * 
 */
public class ReaderBuilder {

    /**
     * Singleton instance created
     */
    private static ReaderBuilder instance = null;

    private ReaderBuilder() {
    }

    public static ReaderBuilder getInstance() {
        if (ReaderBuilder.instance == null) {
            ReaderBuilder.instance = new ReaderBuilder();
        }
        return ReaderBuilder.instance;
    }

    private enum FileExtentions {
        CSV("csv"), TXT("txt"), PROPERTIES("properties"), XLSX("xls"), ;

        private final String ext;

        FileExtentions(final String ext) {
            this.ext = ext;
        }

        boolean isSameExtension(final String extension) {
            return StringUtils.equalsIgnoreCase(this.ext, extension);
        }

    }

    /** LOGGER for current class */
    final static Logger LOGGER = Logger.getLogger(ReaderBuilder.class.getName());

    /**
     * Builds reader
     * 
     * @param inputFile file whose reader to be built
     * @return Reader
     * @throws ReadingBuilderFailed if reader is not found
     */

    public Reader buildReader(final File inputFile, final String encoding) {
        return getDefaultFileReader(inputFile, encoding);
    }

    public Reader buildReader(final File inputFile, final String beanClassName, final String delimiter) throws ReadException {
        return getReaderByExtension(inputFile, beanClassName, delimiter);
    }

    private Reader getDefaultFileReader(final File inputFile, final String encoding) {
        return new FileReader(inputFile, encoding);
    }

    /**
     * based on extension returns reader
     * 
     * @param inputFile whose reader needs to return
     * @return Reader based on extension of file
     * @throws ReadingBuilderFailed if none of the specified extension found
     */
    private Reader getReaderByExtension(final File inputFile, final String beanClassName, final String delimiter) throws ReadException {
        Reader reader = null;
        final String fileType = getFileExtension(inputFile);
        if (StringUtils.isNotBlank(delimiter) || FileExtentions.CSV.isSameExtension(fileType) || FileExtentions.XLSX.isSameExtension(fileType)) {
            reader = new CharacterSeparatedDataReader(inputFile, beanClassName, delimiter);
        } else if (FileExtentions.PROPERTIES.isSameExtension(fileType)) {
            reader = new PropertiesFileReader(inputFile);
        } else {
            ReaderBuilder.LOGGER.log(Level.ERROR, "can not find the reader by extension");
            throw new ReadException(" can not find appropriate reader by extension");
        }
        return reader;
    }

    /**
     * @param inputFile input file
     * @return String returns extension
     */
    public String getFileExtension(final File inputFile) {
        final String name = inputFile.getName();
        return StringUtils.substringAfterLast(name, ".");
    }

}
