
package com.reader;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * Reader to read properties file.
 * 
 * 
 * 
 */
public class PropertiesFileReader implements Reader {

    /** LOGGER for current class */
    final static Logger LOGGER = Logger.getLogger(PropertiesFileReader.class.getName());

    private final File inputFile;

    public PropertiesFileReader(final File inputFile) {
        this.inputFile = inputFile;
    }

    /**
     * This method returns the map of properties.
     * 
     * @param inputFile input properties file
     * @return property map
     * @throws ReaderFailed if properties reader failed
     */

    private Map<String, String> getPropMap(final File inputFile) throws ReadException {

        final Properties prop = new Properties();
        final HashMap<String, String> propvals = new HashMap<>();
        try (InputStream input = new FileInputStream(inputFile.getName())) {

            prop.load(input);
            PropertiesFileReader.LOGGER.log(Level.INFO, "Property file loaded successfully");
            final Set<String> propertyNames = prop.stringPropertyNames();
            for (final String Property : propertyNames) {
                propvals.put(Property, prop.getProperty(Property));
            }
            PropertiesFileReader.LOGGER.log(Level.INFO, "HashMap generated : " + propvals);
            return propvals;
        } catch (final IOException e) {
            PropertiesFileReader.LOGGER.error(Level.ERROR, e);
            throw new ReadException(e.getMessage(), e);
        }
    }

    @Override
    public Map<?, ?> read() throws ReadException {
        return getPropMap(this.inputFile);
    }

}
