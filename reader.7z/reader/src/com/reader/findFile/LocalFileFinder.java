
package com.reader.findFile;

import java.io.File;
import java.io.FileNotFoundException;

/**
 * Find file from local location
 *
 * 
 *
 */
public class LocalFileFinder implements FileFinder {

    /**
     * Absolute file path to local location
     */
    private String absoluteFilePath = null;

    /**
     * Constructor to initialize properties
     *
     * @param absoluteFilePathToBeSet to set file path
     */
    public LocalFileFinder(final String absoluteFilePathToBeSet) {
        this.absoluteFilePath = absoluteFilePathToBeSet;
    }

    /**
     * See if the File exists if yes return the File instance.
     *
     * @throws FileNotFoundException if File does not exists on specified file path.
     */
    @Override
    public File find() throws FileNotFoundException {
        final File foundFileInstance = new File(this.absoluteFilePath);
        if (!foundFileInstance.exists()) {
            throw new FileNotFoundException("No File/Directory was found with path : " + this.absoluteFilePath);
        }
        return foundFileInstance;
    }
}
