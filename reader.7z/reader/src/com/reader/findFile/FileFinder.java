
package com.reader.findFile;

import java.io.File;


public interface FileFinder {

    /**
     * Find the file on given location
     *
     * @return File instance of File asked to find.
     * @throws Exception occurred during finding the file on given location
     */
    File find() throws Exception;

}
