
package com.reader.findFile;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.commons.vfs2.impl.StandardFileSystemManager;
import org.apache.log4j.Logger;

import com.reader.request.Credentials;


public class FTPFileFinder implements FileFinder {

    /**
     * LOGGER for current class
     */
    private final static Logger LOGGER = Logger.getLogger(FTPFileFinder.class);
    /**
     * File path from the FTP location
     */
    private String absoluteRemoteFilePath = null;
    /**
     * Object of Credentials to access FTP
     */
    private Credentials credentials = null;
    /**
     * True if given absoluteRemoteFilePath is directory, False if given absoluteRemoteFilePath is file.
     */
    private Boolean isDirRead = null;
    /**
     * Temporary file location on local machine to save file/files. These file/Files are going to be deleted
     * after reading.
     */
    private String tempLocalDirPath = null;

    /**
     * Constructor of FTPFileFinder
     *
     * @param absoluteFilePathToBeSet absolute file path to the file
     * @param credentialsToBeSet to access FTP location
     * @param isDirReadToBeSet if provided name is file or directory
     * @param tempLocalDirPathToBeSet file path to store file/Files temporarily
     */
    public FTPFileFinder(final String absoluteFilePathToBeSet, final Credentials credentialsToBeSet, final Boolean isDirReadToBeSet, final String tempLocalDirPathToBeSet) {
        this.absoluteRemoteFilePath = absoluteFilePathToBeSet;
        this.credentials = credentialsToBeSet;
        this.isDirRead = isDirReadToBeSet;
        this.tempLocalDirPath = tempLocalDirPathToBeSet;
    }

    /**
     * Copy file from FTP into temporary location. Return instance of file copied into temporary location.
     *
     * @throws Exception throws if error occurred during downloading file from specified FTP location into
     *             temporary location.
     */
    @Override
    public File find() throws Exception {
        try {
            copyFileFromFTP();
        } catch (final IOException exception) {
            FTPFileFinder.LOGGER.error(" exception while downloading file from FTP", exception);
            throw new Exception(" exception while downloading file from FTP", exception);
        }
        this.tempLocalDirPath += "/" + this.absoluteRemoteFilePath;
        System.out.println(" tempLocalDirPath " + this.tempLocalDirPath);
        final File foundFileInstance = new File(this.tempLocalDirPath);
        System.out.println(" foundFileInstance " + foundFileInstance);
        if (!foundFileInstance.exists()) {
            FTPFileFinder.LOGGER.error("Error while creating temp file path of " + this.tempLocalDirPath);
            throw new FileNotFoundException("Error while creating temp file path of " + this.tempLocalDirPath);
        }
        return foundFileInstance;
    }

    /**
     * Connect to FTP and download file from FTP location into Local temporary location
     *
     * @throws Exception throws if FTP connection failed, log in failed or file can not get downloaded.
     */
    private void copyFileFromFTP() throws Exception {
        final StandardFileSystemManager manager = new StandardFileSystemManager();
        try {
            manager.init();

            String remoteFilePath = this.absoluteRemoteFilePath;
            // File directly on root of ftp to handle this case -- see client for files not at root
            // level there is "/" already
            // we need "/" because we are concatenating temp folder path string and remote path.
            if (!remoteFilePath.startsWith("/")) {
                remoteFilePath = "/" + remoteFilePath;
            }
            System.out.println(" remote file path is " + remoteFilePath);
            FTPUtil.downloadFileFromFTP(manager, this.credentials, remoteFilePath, this.tempLocalDirPath);
        } finally {
            manager.close();
        }
    }
}