
package com.reader.findFile;

import java.io.File;

import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemException;
import org.apache.commons.vfs2.FileSystemOptions;
import org.apache.commons.vfs2.Selectors;
import org.apache.commons.vfs2.impl.StandardFileSystemManager;
import org.apache.commons.vfs2.provider.sftp.SftpFileSystemConfigBuilder;
import org.apache.log4j.Logger;

import com.reader.request.Credentials;

public class FTPUtil {

    /**
     * LOGGER for current class
     */
    private final static Logger LOGGER = Logger.getLogger(FTPUtil.class);

    /**
     * Get the remoteFile object and download to local machine.
     * 
     * @param manager to locate files.
     * @param credentials to access ftp server.
     * @param remoteFilePath path from root of the server.
     * @param tempLocalDirPath path where file to be saved
     * @throws Exception if downloading fails.
     */
    public static void downloadFileFromFTP(final StandardFileSystemManager manager, final Credentials credentials, final String remoteFilePath, final String tempLocalDirPath) throws Exception {
        final FileObject remoteFile = manager.resolveFile(FTPUtil.createConnectionString(credentials.getHostName(), credentials.getUserName(), credentials.getPassword(), remoteFilePath), FTPUtil.createDefaultOptions());
        FTPUtil.LOGGER.info("File to downloaded from ftp is of type " + remoteFile.getType());
        final String localAbsoluteFilePath = tempLocalDirPath + remoteFilePath;
        FTPUtil.downloadFile(manager, remoteFile, localAbsoluteFilePath);
    }

    /**
     * create temp folder structures and copy files into them
     * 
     * @param manager to locate files.
     * @param remoteFile instance of FileObject of remote file
     * @param localFilePath where file has to be saved
     * @throws Exception if file copying fails.
     */
    public static void downloadFile(final StandardFileSystemManager manager, final FileObject remoteFile, final String localFilePath) throws Exception {
        final File downloadFile = new File(localFilePath);
        final File parentDir = downloadFile.getParentFile();
        if (!parentDir.exists()) {
            parentDir.mkdirs();
        }
        try {
            final FileObject localFile = manager.resolveFile(downloadFile.getAbsolutePath());
            // Copy local file to sftp server
            localFile.copyFrom(remoteFile, Selectors.SELECT_ALL);
        } catch (final FileSystemException exception) {
            throw new Exception(" Error while copying file from ftp ", exception);
        }

    }

    /**
     * To get file by URI
     * 
     * @param hostName server name
     * @param username part of credentials
     * @param password part of credentials
     * @param remoteFilePath path upto file location
     * @return locate a file by URI
     */
    public static String createConnectionString(final String hostName, final String username, final String password, final String remoteFilePath) {
        return "sftp://" + username + ":" + password + "@" + hostName + "/" + remoteFilePath;
    }

    /**
     * Fo file-system creation
     * 
     * @return options for the FileSystem
     * @throws FileSystemException if the file cannot be located or an error occurs.
     */
    public static FileSystemOptions createDefaultOptions() throws FileSystemException {
        // Create SFTP options
        final FileSystemOptions opts = new FileSystemOptions();
        // SSH Key checking
        SftpFileSystemConfigBuilder.getInstance().setStrictHostKeyChecking(opts, "no");
        /*
         * Using the following line will cause VFS to choose File System's Root as VFS's root. If I wanted to
         * use User's home as VFS's root then set 2nd method parameter to "true"
         */
        // Root directory set to user home
        SftpFileSystemConfigBuilder.getInstance().setUserDirIsRoot(opts, false);
        // Timeout is count by Milliseconds
        SftpFileSystemConfigBuilder.getInstance().setTimeout(opts, 10000);
        return opts;
    }
}