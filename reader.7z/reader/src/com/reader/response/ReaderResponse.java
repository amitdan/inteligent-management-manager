
package com.reader.response;

import java.util.HashMap;

/**
 * Create ReaderResponse object which has been returned from ReaderService
 *
 * 
 *
 */
public class ReaderResponse extends HashMap {

    /**      */
    private static final long serialVersionUID = -7507781015702305205L;
    private Object result = null;

    public ReaderResponse(final Object result) {
        this.result = result;
    }

    public Object getResult() {
        return this.result;
    }
}
