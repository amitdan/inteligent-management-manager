
package com.reader.request;

import java.io.FilenameFilter;
import java.util.HashMap;

import org.apache.commons.lang3.Validate;
import org.apache.log4j.Logger;

import com.reader.ReadException;

/**
 * Create ReaderRequest object which going to get passed in ReaderService to process.
 *
 * 
 *
 */
public class ReaderRequest extends HashMap {

    /** LOGGER for current class */
    final static Logger LOGGER = Logger.getLogger(ReaderRequest.class.getName());

    private static final long serialVersionUID = 1L;
    /**
     * To filter files if reader request is for direcotry read.
     */
    private final FilenameFilter fileNameFilter = null;
    /**
     * Specify location of file i.e. if file is local or FTP.
     */
    private ReadType readType = null;
    /**
     * Absolute path of file to be read
     */
    private String fileAbsolutePath = null;
    /**
     * If reader should read Directory or File.
     */
    private Boolean isDirRead = null;
    /**
     * Fully classified name of bean to be mapped with File/Directory
     */
    private String beanName = null;
    /**
     * Specify delimiter
     */
    private String delimiter = null;
    /**
     * Encoding type
     */
    private String encoding = null;
    /**
     * If needs credentials to access location of File/Directory
     */
    private Credentials credentials = null;
    /**
     * If delete copied files from remote from local machine
     */
    private Boolean ifDeleteTempFiles = null;

    ReaderRequest(final ReadType readType, final String fileName, final Boolean isDirRead, final String beanName, final String delimiter, final String encoding, final Credentials credentials, final Boolean ifDeleteTempFiles) throws ReadException {
        Validate.notNull(readType, " readType can not be null");
        Validate.notNull(fileName, " fileName can not be null");
        this.readType = readType;
        this.fileAbsolutePath = fileName;
        this.credentials = credentials;
        this.isDirRead = isDirRead;
        this.beanName = beanName;
        this.delimiter = delimiter;
        this.encoding = encoding;
        this.ifDeleteTempFiles = ifDeleteTempFiles;
    }

    public ReadType getReadType() {
        return this.readType;
    }

    public String getBeanName() {
        return this.beanName;
    }

    public boolean isBeanReadRequest() {
        return this.beanName != null;
    }

    public boolean isCharacterSeparatedDataReadRequest() {
        return this.delimiter != null;
    }

    public Boolean getIsDirRead() {
        return this.isDirRead;
    }

    public String getDelimiter() {
        return this.delimiter;
    }

    public String getEncoding() {
        return this.encoding;
    }

    public FilenameFilter getFileNameFilter() {
        return this.fileNameFilter;
    }

    public String getFileAbsolutePath() {
        return this.fileAbsolutePath;
    }

    public void setFileAbsolutePath(final String fileAbsolutePath) {
        this.fileAbsolutePath = fileAbsolutePath;
    }

    private void setCredentials(final Credentials credentials) {
        this.credentials = credentials;
    }

    public Credentials getCredentials() {
        return this.credentials;
    }

    public Boolean getIfDeleteTempFiles() {
        return this.ifDeleteTempFiles;
    }

    public void setIfDeleteTempFiles(final Boolean ifDeleteTempFiles) {
        this.ifDeleteTempFiles = ifDeleteTempFiles;
    }

}
