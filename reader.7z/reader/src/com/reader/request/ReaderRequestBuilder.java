
package com.reader.request;

import com.reader.ReadException;

/**
 * It build ReaderRequest based on parameters provided.
 *
 * 
 *
 */
public class ReaderRequestBuilder {

    /**
     * builder instance
     */
    private static ReaderRequestBuilder instance = null;

    public static ReaderRequestBuilder getInstance() {
        if (ReaderRequestBuilder.instance == null) {
            ReaderRequestBuilder.instance = new ReaderRequestBuilder();
        }
        return ReaderRequestBuilder.instance;
    }

    public ReaderRequest buildReaderRequestForLocalDirectoryReadOperation(final String fileAbsolutePath, final String delimiter, final String encoding) throws ReadException {
        return new ReaderRequest(ReadType.LOCAL, fileAbsolutePath, Boolean.TRUE, null, delimiter, encoding, null, false);
    }

    public ReaderRequest buildReaderRequestForLocalFileReadOperation(final String fileAbsolutePath, final String delimiter, final String encoding) throws ReadException {
        return new ReaderRequest(ReadType.LOCAL, fileAbsolutePath, Boolean.FALSE, null, delimiter, encoding, null, false);
    }

    public ReaderRequest buildBeanReaderRequestForLocalDirectoryReadOperation(final String fileAbsolutePath, final String fullqualifiedBeanClassName, final String delimiter, final String encoding) throws ReadException {
        return new ReaderRequest(ReadType.LOCAL, fileAbsolutePath, Boolean.TRUE, fullqualifiedBeanClassName, delimiter, encoding, null, false);
    }

    public ReaderRequest buildBeanReaderRequestForLocalFileReadOperation(final String fileAbsolutePath, final String fullqualifiedBeanClassName, final String delimiter, final String encoding) throws ReadException {
        return new ReaderRequest(ReadType.LOCAL, fileAbsolutePath, Boolean.FALSE, fullqualifiedBeanClassName, delimiter, encoding, null, false);
    }

    public ReaderRequest buildReaderRequestForFTPDirectoryReadOperation(final String fileAbsolutePath, final String delimiter, final String encoding, final Credentials credentials) throws ReadException {
        return new ReaderRequest(ReadType.FTP, fileAbsolutePath, Boolean.TRUE, null, delimiter, encoding, credentials, true);
    }

    public ReaderRequest buildReaderRequestForFTPFileReadOperation(final String fileAbsolutePath, final String delimiter, final String encoding, final Credentials credentials, final boolean ifDeleteTempFiles) throws ReadException {
        return new ReaderRequest(ReadType.FTP, fileAbsolutePath, Boolean.FALSE, null, delimiter, encoding, credentials, ifDeleteTempFiles);
    }

    public ReaderRequest buildBeanReaderRequestForFTPDirectoryReadOperation(final String fileAbsolutePath, final String fullqualifiedBeanClassName, final String delimiter, final String encoding, final Credentials credentials, final boolean ifDeleteTempFiles) throws ReadException {
        return new ReaderRequest(ReadType.FTP, fileAbsolutePath, Boolean.TRUE, fullqualifiedBeanClassName, delimiter, encoding, credentials, ifDeleteTempFiles);
    }

    public ReaderRequest buildBeanReaderRequestForFTPFileReadOperation(final String fileAbsolutePath, final String fullqualifiedBeanClassName, final String delimiter, final String encoding, final Credentials credentials, final boolean ifDeleteTempFiles) throws ReadException {
        return new ReaderRequest(ReadType.FTP, fileAbsolutePath, Boolean.FALSE, fullqualifiedBeanClassName, delimiter, encoding, credentials, ifDeleteTempFiles);
    }

}
