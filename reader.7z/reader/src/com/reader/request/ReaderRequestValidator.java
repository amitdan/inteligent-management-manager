package com.reader.request;

import java.io.File;

import com.reader.ReadException;

/**
 * To validate ReaderRequest created by user,
 *
 * 
 *
 */
public class ReaderRequestValidator {

    /**
     * Validate Reader request
     *
     * @param readerRequest instance of ReaderRequest to validate
     * @param file to be read
     * @throws ReadException if not valid readerRequest throws.
     */
    public static void validate(final ReaderRequest readerRequest, final File file) throws ReadException {
        if (readerRequest.getIsDirRead() && !file.isDirectory()) {
            throw new ReadException(" Identified input is a file when looking for directory");
        }
        if (!readerRequest.getIsDirRead() && file.isDirectory()) {
            throw new ReadException(" Identified input is a directory when looking for file");
        }
    }

}
