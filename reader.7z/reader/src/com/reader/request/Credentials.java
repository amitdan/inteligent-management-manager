
package com.reader.request;

/**
 * Bean class for Credentials
 *
 * 
 */
public class Credentials {

    String userName;
    String password;
    String hostName;
    int port = 21;

    public Credentials(final String userName, final String password, final String hostName, final int port) {
        super();
        this.port = port;
    }

    public Credentials(final String userName, final String password, final String hostName) {
        this.userName = userName;
        this.password = password;
        this.hostName = hostName;
    }

    public String getUserName() {
        return this.userName;
    }

    public void setUserName(final String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(final String password) {
        this.password = password;
    }

    public String getHostName() {
        return this.hostName;
    }

    public void setHostName(final String hostName) {
        this.hostName = hostName;
    }

    public int getPort() {
        return this.port;
    }

    public void setPort(final int port) {
        this.port = port;
    }
}
