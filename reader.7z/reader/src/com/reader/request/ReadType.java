package com.reader.request;

/**
 * Provided types of location from where file can be read
 *
 * 
 *
 */
public enum ReadType {

    /**
     * Read from local location
     */
    LOCAL,
    /**
     * Read from FTP location
     */
    FTP;

}
