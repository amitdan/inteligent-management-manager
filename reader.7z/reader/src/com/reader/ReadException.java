
package com.reader;

/**
 * Read Exception thrown
 * 
 * 
 * 
 */
public class ReadException extends Exception {

    private static final long serialVersionUID = 1L;

    /**
     * @param paramString error message passed
     */
    public ReadException(final String paramString) {
        super(paramString);
    }

    /**
     * @param paramString error message passed
     * @param paramThrowable instance of exception
     */
    public ReadException(final String paramString, final Throwable paramThrowable) {
        super(paramString, paramThrowable);
    }
}
