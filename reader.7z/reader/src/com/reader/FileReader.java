
package com.reader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.log4j.Logger;

/**
 * File reader for simple file read
 * 
 * 
 * 
 */
public class FileReader implements Reader {

    File fileToRead = null;
    String encoding = null;

    /** LOGGER for current class */
    final static Logger LOGGER = Logger.getLogger(FileReader.class.getName());

    public FileReader(final File fileToRead, final String encoding) {
        this.fileToRead = fileToRead;
        this.encoding = encoding;
    }

    public FileReader(final File fileToRead) {
        this.fileToRead = fileToRead;
    }

    @Override
    public Object read() throws ReadException {
        final StringBuffer buffer = new StringBuffer();
        BufferedReader br = null;
        try {
            if (this.encoding != null) {
                br = new BufferedReader(new InputStreamReader(new FileInputStream(this.fileToRead), this.encoding));
            } else {
                br = new BufferedReader(new java.io.FileReader(this.fileToRead));
            }
            final char[] chars = new char[4096];
            int numRead = br.read(chars);
            while (numRead >= 0) {
                buffer.append(chars, 0, numRead);
                numRead = br.read(chars);
            }

        } catch (final IOException exception) {
            FileReader.LOGGER.error("Error in FileReader..", exception);
            throw new ReadException("Error in FileReader..", exception);
        } finally {
            try {
                if (br != null) {
                    br.close();
                }
            } catch (final IOException exception) {
                FileReader.LOGGER.error("Error in FileReader..", exception);
                throw new ReadException("Error in FileReader..", exception);
            }
        }
        return buffer.toString();
    }
}
