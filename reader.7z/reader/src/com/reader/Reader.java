
package com.reader;

/**
 * Reader interface
 * 
 * 
 * 
 */
public interface Reader {

    /**
     * This interface provides a contract to return file in object format. Input parameters are being passed
     * by implementing classes' constructor. To support file to output in any format, Object has been made as
     * return type. Using properties set in implementing classes, read operation has been overridden in
     * corresponding classes.
     * 
     * @return Object file contents
     * @throws ReadException if read failed
     */
    Object read() throws ReadException;
}
