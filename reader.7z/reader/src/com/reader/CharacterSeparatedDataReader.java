
package com.reader;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.apache.log4j.Logger;

import com.googlecode.jcsv.CSVStrategy;
import com.googlecode.jcsv.annotations.internal.ValueProcessorProvider;
import com.googlecode.jcsv.reader.CSVEntryParser;
import com.googlecode.jcsv.reader.CSVReader;
import com.googlecode.jcsv.reader.internal.AnnotationEntryParser;
import com.googlecode.jcsv.reader.internal.CSVReaderBuilder;

/**
 * Implementation of Reader for CSV file
 * 
 * 
 */
public class CharacterSeparatedDataReader implements Reader {

    private final File sourceFile;
    private final Class<?> beanClass;
    private final Character delimiter;

    /** LOGGER for current class */
    final static Logger LOGGER = Logger.getLogger(CharacterSeparatedDataReader.class.getName());

    /**
     * @param sourceFile instance of File to be read
     * @param beanClassName fully qualified class name of bean
     * @param delimiter used in file
     * @throws ReadException if class not been found
     */
    public CharacterSeparatedDataReader(final File sourceFile, final String beanClassName, final String delimiter) throws ReadException {
        this.sourceFile = sourceFile;
        this.delimiter = delimiter.charAt(0);
        try {
            this.beanClass = Class.forName(beanClassName);
        } catch (final ClassNotFoundException exception) {
            CharacterSeparatedDataReader.LOGGER.error("Invalid bean name: " + beanClassName, exception);
            throw new ReadException("Invalid bean name: " + beanClassName, exception);
        }
    }

    /**
     * Read from csv file using jcsv API
     */
    @Override
    public List read() throws ReadException {
        List returnedList = null;
        final CharacterSeparatedDataContext context = new CharacterSeparatedDataContext(this.sourceFile, this.beanClass, this.delimiter);
        try (final java.io.Reader reader = new FileReader(this.sourceFile)) {
            final ValueProcessorProvider provider = new ValueProcessorProvider();
            final CSVEntryParser entryParser = new AnnotationEntryParser(this.beanClass, provider);
            final CSVStrategy st = buildStrategy(context);
            final CSVReader csvReader = new CSVReaderBuilder(reader).strategy(st).entryParser(entryParser).build();
            returnedList = csvReader.readAll();
        } catch (final IOException exception) {
            CharacterSeparatedDataReader.LOGGER.error("Reader failed : ", exception);
            throw new ReadException("Reader failed : ", exception);
        }
        return returnedList;
    }

    /**
     * build CSVStrategy
     * 
     * @param strategy strategy to parse CSV file
     * @return CSVStrategy
     */
    private CSVStrategy buildStrategy(final CharacterSeparatedDataContext strategy) {
        return new CSVStrategy(strategy.getDelimiter(), strategy.getQuoteCharacter(), strategy.getCommentIndicator(), strategy.isSkipHeader(), strategy.isIgnoreEmptyLines());
    }
}
