
package com.reader;

import java.io.File;

import org.apache.log4j.Logger;

/**
 * Context set before reading csv file
 *
 * 
 *
 */
public class CharacterSeparatedDataContext {

    /** Logger */
    final static Logger LOGGER = Logger.getLogger(CharacterSeparatedDataContext.class.getName());
    /** input file */
    File inputFile;
    /** class name */
    Class<?> className;
    /** delimiter */
    char delimiter = ',';
    /** quote character */
    char quoteCharacter = '"';
    /** comment indicator */
    char commentIndicator = '#';
    /** skip header */
    Boolean skipHeader = Boolean.TRUE;
    
    /** Ignore empty lines */
    Boolean ignoreEmptyLines = Boolean.TRUE;

    /**
     * @param inputFileToBeSet file
     * @param inputClass class
     * @param delimiterToBeSet character
     */
    public CharacterSeparatedDataContext(final File inputFileToBeSet, final Class<?> inputClass, final Character delimiterToBeSet) {
        this.inputFile = inputFileToBeSet;
        this.className = inputClass;
        this.delimiter = delimiterToBeSet;
    }

    /**
     * @return delimiter
     */
    public char getDelimiter() {
        return this.delimiter;
    }

    /**
     * @return quote character
     */
    public char getQuoteCharacter() {
        return this.quoteCharacter;
    }

    /**
     * @return comment indicator
     */
    public char getCommentIndicator() {
        return this.commentIndicator;
    }

    /**
     * @return boolean
     */
    public boolean isSkipHeader() {
        return this.skipHeader;
    }

    /**
     * @return boolean
     */
    public boolean isIgnoreEmptyLines() {
        return this.ignoreEmptyLines;
    }

    /**
     * @param delimiterToBeSet set delimiter
     */
    public void setDelimiter(final char delimiterToBeSet) {
        this.delimiter = delimiterToBeSet;
    }

    /**
     * @param quoteCharacterToBeSet set quote character
     */
    public void setQuoteCharacter(final char quoteCharacterToBeSet) {
        this.quoteCharacter = quoteCharacterToBeSet;
    }

    /**
     * @param commentIndicatorToBeSet set comment indicator
     */
    public void setCommentIndicator(final char commentIndicatorToBeSet) {
        this.commentIndicator = commentIndicatorToBeSet;
    }

    /**
     * @param skipHeaderToBeSet set skip header
     */
    public void setSkipHeader(final boolean skipHeaderToBeSet) {
        this.skipHeader = skipHeaderToBeSet;
    }

    /**
     * @param ignoreEmptyLinesToBeSet set ignore empty lines
     */
    public void setIgnoreEmptyLines(final boolean ignoreEmptyLinesToBeSet) {
        this.ignoreEmptyLines = ignoreEmptyLinesToBeSet;
    }

    /**
     * @return input file
     */
    public File getInputFile() {
        return this.inputFile;
    }

    /**
     * @param inputFileToBeSet set input file
     */
    public void setInputFile(final File inputFileToBeSet) {
        this.inputFile = inputFileToBeSet;
    }

    /**
     * @return class name
     */
    public Class<?> getClassName() {
        return this.className;
    }

    /**
     * @param classNameToBeSet set class name
     */
    public void setClassName(final Class<?> classNameToBeSet) {
        this.className = classNameToBeSet;
    }
}
