
package com.reader.service;

import java.io.File;
import java.security.InvalidParameterException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.reader.ReadException;
import com.reader.Reader;
import com.reader.ReaderBuilder;
import com.reader.findFile.FTPFileFinder;
import com.reader.findFile.FileFinder;
import com.reader.findFile.LocalFileFinder;
import com.reader.request.ReadType;
import com.reader.request.ReaderRequest;
import com.reader.request.ReaderRequestValidator;
import com.reader.response.ReaderResponse;

/**
 * Gets reader by extension and call reader to read.
 *
 * 
 *
 */
public class ReaderService {

    /** LOGGER for current class */
    final static Logger LOGGER = Logger.getLogger(ReaderService.class.getName());

    /**
     * Provide singleton instance of ReaderBuilder
     */
    ReaderBuilder readerBuilder = ReaderBuilder.getInstance();

    /**
     * Singleton instance ReaderService provides
     */
    private static ReaderService instance = null;

    /**
     * It is an absolute path where files from remote location will be downloaded
     */
    String tempFileStorePath = null;

    /**
     * Provide singleton instance of ReaderService
     *
     * @return instance of ReaderService
     */
    public static ReaderService getInstance() {
        if (ReaderService.instance == null) {
            ReaderService.instance = new ReaderService();
        }
        return ReaderService.instance;
    }

    /**
     * Using FileFinder finds file/Directory and reads data from it to store it on object which will
     * ultimately wrapped in ReaderResponse.
     *
     * @param readerRequest contains all the information to read the file.
     * @return object of ReaderResponse which contains data of file or Directory which has been read.
     * @throws ReadException if any exception occurred during reading of file.
     */
    public ReaderResponse read(final ReaderRequest readerRequest) throws ReadException {
        try {
            final File file = findFile(readerRequest);
            ReaderRequestValidator.validate(readerRequest, file);
            final Object obj = read(readerRequest, file);
            if (readerRequest.getIfDeleteTempFiles()) {
                ReaderService.deleteTempFiles(new File(this.tempFileStorePath));
            }
            return new ReaderResponse(obj);
        } catch (final Throwable t) {
            ReaderService.LOGGER.error("Error in ReaderService.", t);
            throw new ReadException("Error in ReaderService." + t);
        }
    }

    /**
     * Read file depending upon if it is directory read or file read.
     *
     * @param readerRequest contains all the information to read the file.
     * @param file instance of File to read
     * @return Object file data
     * @throws ReadException if file reading failed
     */
    private Object read(final ReaderRequest readerRequest, final File file) throws ReadException {
        Object obj = null;
        if (readerRequest.getIsDirRead()) {
            obj = handleDirectoryRead(file, readerRequest);
        } else {
            obj = handleFileRead(file, readerRequest);
        }
        return obj;
    }

    /**
     * Build instance of FileFinder and get the File instance of file to be found.
     *
     * @param readerRequest contains all the information to read the file.
     * @return File instance
     * @throws Exception if exception occurs while finding file
     */
    private File findFile(final ReaderRequest readerRequest) throws Exception {
        final FileFinder fileFinder = buildFileFinderInstance(readerRequest);
        final File file = fileFinder.find();
        return file;
    }

    /**
     * Empty this directory
     *
     * @param tempLocalDir local directory where temporary files are saved from remote location.
     */
    public static void deleteTempFiles(final File tempLocalDir) {
        System.out.println(" deleteTempFiles " + tempLocalDir.getAbsolutePath());
        final File[] files = tempLocalDir.listFiles();
        if ((files != null) && (files.length > 0)) {
            for (final File file : files) {
                ReaderService.removeFile(file);
            }
        }
        tempLocalDir.delete();
    }

    /**
     * see if it contains another directory inside then call recursively else empty directory
     *
     * @param file File to be deleted.
     */
    public static void removeFile(final File file) {
        if (file.isDirectory()) {
            final File[] files = file.listFiles();
            if ((files != null) && (files.length > 0)) {
                for (final File aFile : files) {
                    ReaderService.removeFile(aFile);
                }
            }
            if (file.delete()) {
                ReaderService.LOGGER.info(" Successfully deleted file :-" + file.getName());
            }
        } else if (file.delete()) {
            ReaderService.LOGGER.info(" Successfully deleted file :-" + file.getName());
        }
    }

    /**
     * read data to map bean with file or to simply read file.
     *
     * @param file object of File to be read.
     * @param request wrapped all the information required to read file.
     * @return map containing file name as key and data inside file as value.
     * @throws ReadException throws if any exception occurred.
     */
    private Object handleFileRead(final File file, final ReaderRequest request) throws ReadException {
        final Map<String, Object> readContents = new HashMap<>();
        final String fileName = file.getName();
        Object readData = new Object();
        if (request.getBeanName() != null) {
            readData = readFromFileToMapBeans(file, request.getBeanName(), request.getDelimiter());
        } else {
            readData = readFromFile(file, request.getEncoding());
        }
        readContents.put(fileName, readData);
        return readContents;
    }

    /**
     * read data to map bean with files in directory or to simply read files in directory.
     *
     * @param directory object of File to be read.
     * @param request wrapped all the information required to read file.
     * @return map containing file name as key and data inside file as value.
     * @throws ReadException if any exception occurs.
     */
    private Object handleDirectoryRead(final File directory, final ReaderRequest request) throws ReadException {
        File[] files;
        if (request.getFileNameFilter() != null) {
            files = directory.listFiles(request.getFileNameFilter());
        } else {
            files = directory.listFiles();
        }
        if (files == null) {
            throw new InvalidParameterException(" abstract pathname does not denote a directory, or  an I/O error occured");
        }
        final Map<String, Object> readContents = new HashMap<>();
        for (int i = 0; i < files.length; i++) {
            final File fileToRead = files[i];
            readContents.putAll((Map<String, Object>) handleFileRead(fileToRead, request));
        }
        return readContents;
    }

    /**
     * Get the reader based on extension and read from it to map with bean class provided
     *
     * @param inputFile object of File to be read.
     * @param beanClassName to map bean with file
     * @param delimiter used in file
     * @return map containing file name as key and data inside file as value.
     * @throws ReadException if any exception occurs
     */
    private Object readFromFileToMapBeans(final File inputFile, final String beanClassName, final String delimiter) throws ReadException {
        final Reader reader = this.readerBuilder.buildReader(inputFile, beanClassName, delimiter);
        return reader.read();
    }

    /**
     * Get the reader based on extension and read from it.
     *
     * @param inputFile object of File to be read.
     * @param encoding file encoding
     * @return map containing file name as key and data inside file as value.
     * @throws ReadException if any exception occurs
     */
    private Object readFromFile(final File inputFile, final String encoding) throws ReadException {
        final Reader reader = this.readerBuilder.buildReader(inputFile, encoding);
        return reader.read();
    }

    /**
     * based on location of file mentioned in read type of request object return instance of FileFinder.
     *
     * @param request wrapped all the information required to read file.
     * @return flavor of FileFinder
     * @throws ReadException if no suitable FileFinder can get instantiated.
     */
    private FileFinder buildFileFinderInstance(final ReaderRequest request) throws ReadException {
        FileFinder fileFinder = null;
        createTempFilePath();
        if (ReadType.LOCAL.equals(request.getReadType())) {
            fileFinder = new LocalFileFinder(request.getFileAbsolutePath());
        } else if (ReadType.FTP.equals(request.getReadType())) {
            fileFinder = new FTPFileFinder(request.getFileAbsolutePath(), request.getCredentials(), request.getIsDirRead(), this.tempFileStorePath);
        } else {
            throw new ReadException("No File finder configured for read type :" + request.getReadType());
        }
        return fileFinder;
    }

    /**
     * If file stored in remote location copy into temporary local location tempFileStorePath is absolute path
     * where files from remote location will be downloaded temporarily at <temp dir location
     * >\InputFilesForDR_ProsDashBoard
     *
     * @throws ReadException throws if directory can not create
     */
    private void createTempFilePath() throws ReadException {
        final String property = "java.io.tmpdir";
        final String tempDir = System.getProperty(property);
		System.out.println("temp directory " + tempDir);
        final DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
        final Date dateobj = new Date();
        this.tempFileStorePath = tempDir +File.separator +"InputFilesForDR_ProsDashBoard"+ File.separator + df.format(dateobj);
        System.out.println(" saved in this dir " + tempDir);
        
        System.out.println(" this.tempFileStorePath " + this.tempFileStorePath);

        final File tempDir1 = new File(this.tempFileStorePath);
		if (tempDir1.exists()) {
            System.out.println("directory exists already..");
        }
        if (!tempDir1.exists()) {
            if (!tempDir1.mkdirs()) {
                ReaderService.LOGGER.error(" Error while creating temp folder "+this.tempFileStorePath);
                throw new ReadException(" Error while creating temp folder "+this.tempFileStorePath);
            }
        }
		
    }
}
