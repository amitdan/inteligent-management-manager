
public class Client {

    public static void main(String[] args) throws ReadException {
        executeSimpleRead();
        executeBeanRead();
        executeDirBeanRead();
        executeFTPSimpleRead();
        executeFTPBeanRead();
        executeFTPDirBeanRead();
    }

    static void executeSimpleRead() throws ReadException {
        ReaderRequestBuilder requestBuilder = ReaderRequestBuilder.getInstance();
        ReaderRequest request = requestBuilder.buildReaderRequestForLocalFileReadOperation("D:\\input files\\TimeAndLabor\\Sample.txt", null, null);
        ReaderService serviceInstance = ReaderService.getInstance();
        ReaderResponse response = serviceInstance.read(request);

        System.out.println(" -------- Simple File Read --------- ");
        System.out.println(response.getResult());
        System.out.println(" ----------------- ");
    }

    static void executeFTPSimpleRead() throws ReadException {
        Credentials credentials = new Credentials("userName", "password", "hostname");
        ReaderRequestBuilder requestBuilder = ReaderRequestBuilder.getInstance();
        Boolean ifDeleteTempFiles = false;
        ReaderRequest request = requestBuilder.buildReaderRequestForFTPFileReadOperation("/folder_name/aanvekar/Random.txt", null, null, credentials, ifDeleteTempFiles);
        ReaderService serviceInstance = ReaderService.getInstance();
        ReaderResponse response = serviceInstance.read(request);

        System.out.println(" -------- Simple File Read From FTP Location --------- ");
        System.out.println(response.getResult());
        System.out.println(" ----------------- ");
    }

    static void executeBeanRead() throws ReadException {
        ReaderRequestBuilder requestBuilder = ReaderRequestBuilder.getInstance();
	// mention absolute file path of file
        ReaderRequest request = requestBuilder.buildBeanReaderRequestForLocalFileReadOperation("D:\\input files\\TimeAndLabor\\201601.csv", TimeAndLaborBean.class.getCanonicalName(), ",", null);
        ReaderService serviceInstance = ReaderService.getInstance();
        ReaderResponse response = serviceInstance.read(request);

        System.out.println(" -------- Single file Bean Mapping --------- ");
        System.out.println(response.getResult());
        System.out.println(" ----------------- ");
    }

    static void executeFTPBeanRead() throws ReadException {
        Credentials credentials = new Credentials("userName", "password", "hostname");
        ReaderRequestBuilder requestBuilder = ReaderRequestBuilder.getInstance();
        Boolean ifDeleteTempFiles = false;
        ReaderRequest request = requestBuilder.buildBeanReaderRequestForFTPFileReadOperation("/folder_name/aanvekar/TimeAndLabor/201601.csv", TimeAndLaborBean.class.getCanonicalName(), ",", null, credentials, ifDeleteTempFiles);
        ReaderService serviceInstance = ReaderService.getInstance();
        ReaderResponse response = serviceInstance.read(request);

        System.out.println(" -------- FTP Single file Bean Mapping --------- ");
        System.out.println(response.getResult());
        System.out.println(" ----------------- ");
    }

    static void executeDirBeanRead() throws ReadException {
        ReaderRequestBuilder requestBuilder = ReaderRequestBuilder.getInstance();
        ReaderRequest request = requestBuilder.buildBeanReaderRequestForLocalDirectoryReadOperation("D:\\input files\\TimeAndLabor", TimeAndLaborBean.class.getCanonicalName(), ",", null);
        ReaderService serviceInstance = ReaderService.getInstance();
        ReaderResponse response = serviceInstance.read(request);

        System.out.println(" -------- Directory Bean Mapping --------- ");
        System.out.println(response.getResult());
        System.out.println(" ----------------- ");
    }

    static void executeFTPDirBeanRead() throws ReadException {
        Credentials credentials = new Credentials("userName", "password", "hostname");
        ReaderRequestBuilder requestBuilder = ReaderRequestBuilder.getInstance();
        Boolean ifDeleteTempFiles = false;
        ReaderRequest request = requestBuilder.buildBeanReaderRequestForFTPDirectoryReadOperation("/folder_name/aanvekar/TimeAndLabor", TimeAndLaborBean.class.getCanonicalName(), ",", null, credentials, ifDeleteTempFiles);
        ReaderService serviceInstance = ReaderService.getInstance();
        ReaderResponse response = serviceInstance.read(request);

        System.out.println(" -------- FTP Directory Bean Mapping --------- ");
        System.out.println(response.getResult());
        System.out.println(" ----------------- ");
    }

}
