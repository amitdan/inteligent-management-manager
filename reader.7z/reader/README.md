# reader
Reader project to read from file and map using bean class.

This project can do following things.


1.  Read CSV file with custom delimiter.

2.  Populate bean provided, bean properties will be popluated with columns of file using mapping provided in bean class.

3. Read CSV file with custom delimiter
	
4. Populate bean provided, bean properties will be popluated with columns of file using mapping provided in bean class.

5. Can be used for simple file reading such as txt file.
	
6. Both Directory as well as Single file reading has been provided.

7. Provision for keeping or deleteing temporary files.



Supporting Files folder includes

1.Cilent.java 

  Shows the use of jar
  
2.Reader.jar

  the jar version of project
  
3.Dependancy.txt

  dependancies need to include 
  
